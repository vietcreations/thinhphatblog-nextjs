import React from "react";
import Link from "next/link";
import Head from "../components/head";
import Nav from "../components/nav";
import NavMin from "../components/nav-min";
import Footer from "../components/footer";
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    Row,
    Col,
    Container,
} from "reactstrap";
import MutiLogo from "../components/muti-logo";
import NavBottom from "../components/nav-bottom";
import Contact from "../components/contact";
import About from "../components/about";
import Features from "../components/features";
import ScrollToTop from "react-scroll-up";
export default class Index extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            modal: false,
            lstProduct: [],
            currProduct: null,
        };

        this.toggle = this.toggle.bind(this);
    }

    componentDidMount = () => {
        let arrProduct = [
            {
                id: 1,
                name: "TP01",
                img: "/static/images/tp01.jpg",
                thanhphan:
                    "<p><b>Thành phần:</b> Hữu cơ: 15%, Stretomycessp: 1x10^6 CFU/g, Azotobectensp: 1x10^5 CFU/g, độ ẩm: 30%.</p>",
                congdung:
                    "<p><b>Công dụng:</b></p><p>- Dùng bón gốc cho các loại cây trồng: Lúa, ngô, khoai, sắn, cây ngắn ngày, cây ăn trái, rau màu, cây công nghiệp.</p><p>- Đặc biệt các vi sinh vật hữu ích và các nguyên tố vi lượng cung cấp chất dinh dưỡng cân đối, hợp lý cho cây trồng giúp cây trồng sinh trưởng phát triển tốt, bộ rễ khỏe, đẻ nhánh nhiều, chống được sâu bệnh, tăng năng xuất và chất lượng nông sản hữu cơ cao.</p>",
                hdsd: "/static/pdf/hdsd-tp01.pdf",
            },
            {
                id: 2,
                name: "TP02",
                img: "/static/images/tp02.jpg",
                thanhphan:
                    "<p><b>Thành phần:</b> Hữu cơ: 15%,  Streptomycessp: 1x10^6 CFU/g, Trichodermasp: 1x10^6 CFU/g, độ ẩm: 30%, các vi sinh vật hữu ích và các nguyên tố vi lượng tốt cho cây trồng.</p>",
                congdung:
                    "<p><b>Công dụng:</b></p><p>- Dùng bón gốc cho các loại cây trồng: Lúa, ngô, khoai, sắn, cây ngắn ngày, cây ăn trái, rau màu, cây công nghiệp.</p><p>- Cung cấp chất dinh dưỡng cân đối, hợp lý cho cây trồng giúp cây trồng sinh trưởng và phát triển tốt, bộ rễ khỏe, đẻ nhánh nhiều, chống được sâu bệnh, tăng năng xuất, chất lượng nông sản hữu cơ cao.</p>",
                hdsd: "/static/pdf/hdsd-tp02.pdf",
            },
            {
                id: 3,
                name: "TP03",
                img: "/static/images/tp03.jpg",
                thanhphan:
                    "<p><b>Thành phần:</b> Hữu cơ: 15%, Streptomycessp: 1x10^6 CFU/g, Azotobectensp: 1 x 10^5 CFU/g, Bacillussubtitis: 1x10^6 CFU/g, độ ẩm: 30%, các vi sinh vật hữu ích và các nguyên tố vi lượng tốt cho cây trồng.</p>",
                congdung:
                    "<p><b>Công dụng:</b></p><p>- Dùng bón gốc cho các loại cây trồng: Lúa, ngô, khoai, sắn, cây ngắn ngày, cây ăn trái, rau màu, cây công nghiệp.</p><p>- Cung cấp chất dinh dưỡng cân đối, hợp lý cho cây trồng giúp cây trồng sinh trưởng và phát triển tốt, bộ rễ khỏe, đẻ nhánh nhiều, tăng năng xuất và chất lượng nông sản hữu cơ cao.</p>",
                hdsd: "/static/pdf/hdsd-tp03.pdf",
            },
            {
                id: 4,
                name: "TP05",
                img: "/static/images/tp05.jpg",
                thanhphan:
                    "<p><b>Thành phần:</b> Hữu cơ: 22%, tỷ lệ C/N: 10, độ ẩm: 30%, PHH2O: 5 và các nguyên tố vi lượng, vi sinh vật hữu ích tốt cho cây trồng.</p>",
                congdung:
                    "<p><b>Công dụng:</b></p><p>- Dùng bón gốc cho các loại cây trồng: Lúa, ngô, khoai, sắn, cây ngắn ngày, cây ăn trái, rau màu, cây công nghiệp.</p><p>- Cung cấp chất dinh dưỡng cân đối, hợp lý cho cây trồng giúp cây trồng sinh trưởng và phát triển tốt, bộ rễ khỏe, đẻ nhánh nhiều, tăng năng xuất và chất lượng nông sản hữu cơ cao.</p>",
                hdsd: "/static/pdf/hdsd-tp05.pdf",
            },
            {
                id: 5,
                name: "TP 2-4-2",
                img: "/static/images/tp242.jpg",
                thanhphan:
                    "<p><b>Thành phần:</b> Hữu cơ: 15%, N: 2%, P2O5: 4%, K2O: 2%, độ ẩm: 25% và các nguyên tố vi lượng tốt cho cây trồng.</p>",
                congdung:
                    "<p><b>Công dụng:</b></p><p>- Dùng bón gốc cho các loại cây trồng: Lúa, ngô, khoai, sắn, cây ngắn ngày, cây ăn trái, rau màu, cây công nghiệp.</p><p>- Cung cấp chất dinh dưỡng cân đối, hợp lý cho cây trồng giúp cây trồng sinh trưởng và phát triển tốt, bộ rễ khỏe, đẻ nhánh nhiều, tăng năng xuất và chất lượng nông sản hữu cơ cao.</p>",
                hdsd: "/static/pdf/hdsd-tp242.pdf",
            },
            {
                id: 6,
                name: "TP 5-3-2",
                img: "/static/images/tp532.jpg",
                thanhphan:
                    "<p><b>Thành phần:</b> Chất hữu cơ: 15%, đạm tổng số (Nts): 5%, Lân hữu hiệu (P2O5hh): 3%, Kali hữu hiệu (K2Ohh): 2%, pHH20: 5, độ ẩm: 25%.</p>",
                congdung:
                    "<p><b>Công dụng:</b></p><p>- Dùng bón gốc cho các loại cây trồng: Lúa, ngô, khoai, sắn, cây ngắn ngày, cây ăn trái, rau màu, cây công nghiệp.</p><p>- Cung cấp hữu cơ cho đất, cải tạo tinh chất đất, bổ sung dinh dưỡng cho cây trồng, tạo thuận lợi cho bộ rễ cây phát triển góp phần nâng cao năng suất, chất lượng cây trồng.</p>",
                hdsd: "/static/pdf/hdsd-tp532.pdf",
            },
        ];

        this.setState({ lstProduct: arrProduct });
    };

    toggle(index) {
        this.setState(
            {
                currProduct: this.state.lstProduct[index],
            },
            () => {
                this.setState({
                    modal: !this.state.modal,
                });
            }
        );
    }
    render() {
        const { lstProduct, currProduct } = this.state;
        let renderProduct = null;

        if (lstProduct.length > 0) {
            renderProduct = lstProduct.map((item, index) => {
                return (
                    <div
                        className="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-6 mb-5"
                        key={index}
                    >
                        <a
                            className="product"
                            href="javascript:;"
                            onClick={() => {
                                this.toggle(index);
                            }}
                        >
                            <div className="p-3">
                                <img
                                    className="img-thumbnail w-100"
                                    src={item.img}
                                />
                                <div className="title-product">
                                    <h5 className="text-center mt-3">
                                        {item.name}
                                        <span>&rarr;</span>
                                    </h5>
                                </div>
                            </div>
                        </a>
                    </div>
                );
            });
        }

        return (
            <div>
                <Head
                    title="Công ty Cổ phần sản xuất phân bón Thịnh Phát"
                    description="CT CP sản xuất phân bón Thịnh Phát chuyên phân bón hữu cơ, phân bón hữu cơ vi sinh, phân bón hữu cơ khoáng."
                    keywords="phân bón, thịnh phát, phân vi sinh, phân hữu cơ, phân hữu cơ vi sinh, phân hữu cơ khoáng"
                />
                <MutiLogo />
                <Nav />
                <NavMin />
                <div
                    id="trang-chu"
                    className="hero background"
                    style={{ backgroundImage: `url('/static/images/bg.png')` }}
                >
                    <div className="spacer" />
                    <div className="spacer" />
                    <div className="spacer" />
                    <div className="container">
                        <div className="position-relative">
                            <img
                                className="logo-company position-relative"
                                style={{ zIndex: "10" }}
                                src="/static/images/logo.png"
                            />
                            <div className="centerCenter">
                                <img
                                    className="light"
                                    src="/static/images/bg-light.png"
                                />
                            </div>
                        </div>
                        <div className="spacer" />
                        <div className="spacer" />
                        <div className="spacer" />
                        <h1 className="title">Giúp cho mùa màng bội thu</h1>
                        <div className="spacer" />
                        <a className="button button-primary" href="#san-pham">
                            <span
                                style={{
                                    background: `url('/static/images/icon-box.png')`,
                                }}
                            />
                            SẢN PHẨM
                        </a>
                    </div>
                    <img className="w-100" src="/static/images/icon-home.svg" />
                </div>
                <About />
                <Features />
                <div
                    id="san-pham"
                    className="pt-5 pb-5"
                    style={{ borderBottom: "1px solid rgba(0,0,0,0.15)" }}
                >
                    <div className="container">
                        <h3 className="text-center mb-5 text-uppercase font-weight-bold">
                            <a href="javascript:;">Chúng tôi có gì?</a>
                        </h3>
                        <div className="row">{renderProduct}</div>
                    </div>
                </div>
                <Contact />
                <NavBottom />
                <Footer />
                <ScrollToTop showUnder={160}>
                    <div className="position-relative backTop">
                        <img src="/static/images/top.png" />
                    </div>
                </ScrollToTop>
                <Modal
                    isOpen={this.state.modal}
                    toggle={this.toggle}
                    className={this.props.className}
                    style={{ maxWidth: "960px" }}
                >
                    <ModalHeader toggle={this.toggle}>
                        {currProduct ? currProduct.name : ""}
                    </ModalHeader>
                    <ModalBody>
                        <Container>
                            <Row>
                                <Col xs={12} md={3}>
                                    <div className="text-center mb-3">
                                        <img
                                            className="w-100 img-thumbnail"
                                            src={
                                                currProduct
                                                    ? currProduct.img
                                                    : ""
                                            }
                                        />
                                    </div>
                                </Col>
                                <Col xs={12} md={9}>
                                    <div
                                        dangerouslySetInnerHTML={{
                                            __html: currProduct
                                                ? currProduct.thanhphan
                                                : "",
                                        }}
                                    />
                                    <div
                                        dangerouslySetInnerHTML={{
                                            __html: currProduct
                                                ? currProduct.congdung
                                                : "",
                                        }}
                                    />
                                    <a
                                        className="button button-secondary"
                                        href={
                                            currProduct ? currProduct.hdsd : ""
                                        }
                                    >
                                        <span
                                            style={{
                                                background: `url('/static/images/icon-pdf.png')`,
                                            }}
                                        />
                                        HƯỚNG DẪN SỬ DỤNG
                                    </a>
                                </Col>
                            </Row>
                        </Container>
                    </ModalBody>
                    <ModalFooter>
                        <Button color="secondary" onClick={this.toggle}>
                            Tắt
                        </Button>
                    </ModalFooter>
                </Modal>
            </div>
        );
    }
}
