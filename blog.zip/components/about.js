import React from "react";
import "../sass/styles.scss";
import { Row, Col, Container } from "reactstrap";

export default class About extends React.Component {
    render() {
        return (
            <div id="gioi-thieu">
                <Container>
                    <div className="mt-5 mb-5 pt-5 pb-5">
                        <Row>
                            <Col xs={12} md={6}>
                                <h5 className="mb-3 mt-3 text-uppercase font-weight-bold">
                                    <a href="javascript:;">
                                        Phân bón hữu cơ Thịnh Phát
                                    </a>
                                </h5>
                                <p>
                                    Hiện nay, môi trường đất đang ngày càng bị ô
                                    nhiễm nặng nề do hoạt động sản xuất nông
                                    nghiệp. Việc lạm dụng phân bón vô cơ của
                                    người trồng không những làm tăng lượng tồn
                                    dư hóa học trong nông sản, mà còn ảnh hưởng
                                    không nhỏ tới môi trường đất.
                                </p>
                                <p>
                                    Công ty Cổ phần sản xuất phân bón Thịnh Phát
                                    ra đời nhằm giúp cho bà con nông dân có được
                                    mùa màng bội thu bằng việc đưa vào sử dụng
                                    phân bón hữu cơ trong quá trình sản xuất
                                    nông nghiệp sạch.
                                </p>
                                <p>
                                    Được cấp chứng nhận:{" "}
                                    <a href="javascript:;">ISO 9001:2008</a> -{" "}
                                    <a href="javascript:;">ISO 14001:2004</a>
                                </p>
                            </Col>
                            <Col xs={12} md={6}>
                                <img
                                    className="w-100 rounded"
                                    src="/static/images/bg-3.jpg"
                                />
                            </Col>
                        </Row>
                    </div>
                </Container>
            </div>
        );
    }
}
