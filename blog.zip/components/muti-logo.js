import React from "react";
import "../sass/styles.scss";

export default class MutiLogo extends React.Component {
    componentDidMount() {
        $(".responsive").slick({
            slidesToShow: 11,
            slidesToScroll: 1,
            infinite: true,
            prevArrow: $(`#prev-slide`),
            nextArrow: $(`#next-slide`),
            responsive: [
                {
                    breakpoint: 1025,
                    settings: {
                        slidesToShow: 7,
                        slidesToScroll: 1,
                        infinite: true,
                    },
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 5,
                        slidesToScroll: 1,
                    },
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                    },
                },
            ],
        });
    }

    render() {
        return (
            <div>
                <div className="position-relative">
                    <div
                        id="prev-slide"
                        className="centerHeight"
                        style={{ left: "5px", zIndex: 100 }}
                    >
                        &larr;{" "}
                    </div>
                    <div className="col-12">
                        <div className="responsive">
                            <a
                                href="https://hanaspeak.com/"
                                className="carousel-item"
                                target="_blank"
                            >
                                <img src="/static/images/logo-hanaspeak.svg" />
                            </a>
                            <a
                                href="http://nteathainguyen.com/"
                                className="carousel-item"
                                target="_blank"
                            >
                                <img src="/static/images/logo-nteathainguyen.png" />
                            </a>
                            <a
                                href="https://nteadrink.com/"
                                className="carousel-item"
                                target="_blank"
                            >
                                <img src="/static/images/logo-nteadrink.svg" />
                            </a>
                            <a
                                href="http://nte.com.vn/"
                                className="carousel-item"
                                target="_blank"
                            >
                                <img src="/static/images/logo-nte.png" />
                            </a>
                            <a
                                href="https://thinhphat.net/"
                                className="carousel-item"
                                target="_blank"
                            >
                                <img src="/static/images/logo-thinhphat.png" />
                            </a>
                            <div className="carousel-item">
                                <img src="/static/images/logo-ntmedia.svg" />
                            </div>
                            <a
                                href="http://ntea.vn/"
                                className="carousel-item"
                                target="_blank"
                            >
                                <img src="/static/images/logo-ntea.svg" />
                            </a>
                            <div className="carousel-item">
                                <img src="/static/images/logo-nteaquangninh.svg" />
                            </div>
                            <a
                                href="http://kanoshi.vn/"
                                className="carousel-item"
                                target="_blank"
                            >
                                <img src="/static/images/logo-kanoshi.png" />
                            </a>
                            <a
                                href="https://lingo.page/"
                                className="carousel-item"
                                target="_blank"
                            >
                                <img src="/static/images/logo-lingo.svg" />
                            </a>
                            <div className="carousel-item">+</div>
                        </div>
                    </div>
                    <div
                        id="next-slide"
                        className="centerHeight"
                        style={{ right: "5px", zIndex: 100 }}
                    >
                        &rarr;
                    </div>
                    <a href="https://nteagroup.com/" target="_blank">
                        <div
                            className="logo centerWidth"
                            style={{ top: "-20px" }}
                        >
                            <img src="/static/images/logo-nteagroup.svg" />
                        </div>
                    </a>
                </div>
                <div className="banner">
                    <a
                        href="https://nteagroup.com/"
                        className="wrapper"
                        target="_blank"
                    >
                        <span className="title">Tập đoàn NTEA&nbsp;</span>
                        <span className="subtitle">— Hotline: 1800 0068</span>
                        <span className="link">Tìm hiểu &rarr;</span>
                    </a>
                </div>
            </div>
        );
    }
}
