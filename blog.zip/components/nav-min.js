import React from "react";
import Link from "next/link";
import "../sass/styles.scss";

export default class NavMin extends React.Component {
    render() {
        return (
            <nav className="min">
                <ul className="headerNav">
                    <li>
                        <a href="#gioi-thieu">Giới thiệu</a>
                    </li>
                    <li>
                        <a href="#san-pham">Sản phẩm</a>
                    </li>
                    <li>
                        <a href="#lien-he">Liên hệ</a>
                    </li>
                </ul>
            </nav>
        );
    }
}
