import React from "react";
import "../sass/styles.scss";

export default class NavBottom extends React.Component {
    render() {
        return (
            <div className="bottom-link">
                <ul>
                    <li>
                        <a href="/">Trang chủ</a>
                        <span> | </span>
                    </li>
                    <li>
                        <a href="#gioi-thieu">Giới thiệu</a>
                        <span> | </span>
                    </li>
                    <li>
                        <a href="#san-pham">Sản phẩm</a>
                        <span> | </span>
                    </li>
                    <li>
                        <a href="#lien-he">Liên hệ</a>
                    </li>
                </ul>
            </div>
        );
    }
}
