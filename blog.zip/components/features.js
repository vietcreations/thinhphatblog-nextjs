import React from "react";
import "../sass/styles.scss";
import { Row, Col, Container } from "reactstrap";

export default class Features extends React.Component {
    render() {
        return (
            <div
                className="pt-5 pb-5"
                style={{
                    backgroundColor: "#f6fbf9",
                    borderTop: "1px solid #E5EDE9",
                    borderBottom: "1px solid #E5EDE9",
                }}
            >
                <Container>
                    <div className="mt-5 mb-5">
                        <h3 className="text-center mb-3 text-uppercase font-weight-bold">
                            <a href="javascript:;">Phân bón Thịnh Phát</a>
                        </h3>
                        <h5 className="text-center mb-5 text-secondary">
                            Giúp nâng cao chất lượng cây trồng
                        </h5>

                        <Row>
                            <Col xs={12} md={4}>
                                <Row>
                                    <Col xs={8} md={8}>
                                        <p
                                            className="text-right text-secondary"
                                            style={{ lineHeight: "4.4" }}
                                        >
                                            Giải độc tố
                                        </p>
                                    </Col>
                                    <Col xs={4} md={4}>
                                        <img
                                            style={{
                                                width: "64px",
                                                height: "auto",
                                            }}
                                            src="/static/images/icon1.svg"
                                        />
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs={8} md={8}>
                                        <p
                                            className="text-right text-secondary"
                                            style={{ lineHeight: "4.4" }}
                                        >
                                            Cải tạo đất
                                        </p>
                                    </Col>
                                    <Col xs={4} md={4}>
                                        <img
                                            style={{
                                                width: "64px",
                                                height: "auto",
                                            }}
                                            src="/static/images/icon2.svg"
                                        />
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs={8} md={8}>
                                        <p
                                            className="text-right text-secondary"
                                            style={{ lineHeight: "4.4" }}
                                        >
                                            Bảo vệ môi trường
                                        </p>
                                    </Col>
                                    <Col xs={4} md={4}>
                                        <img
                                            style={{
                                                width: "64px",
                                                height: "auto",
                                            }}
                                            src="/static/images/icon3.svg"
                                        />
                                    </Col>
                                </Row>
                            </Col>
                            <Col xs={12} md={4} className="text-center">
                                <img
                                    style={{ width: "250px", height: "250px" }}
                                    src="/static/images/icon-7.svg"
                                />
                            </Col>
                            <Col xs={12} md={4}>
                                <Row>
                                    <Col xs={4} md={4} className="text-right">
                                        <img
                                            style={{
                                                width: "64px",
                                                height: "auto",
                                            }}
                                            src="/static/images/icon4.svg"
                                        />
                                    </Col>
                                    <Col xs={8} md={8}>
                                        <p
                                            className="text-left text-secondary"
                                            style={{ lineHeight: "4.4" }}
                                        >
                                            Tăng năng suất
                                        </p>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs={4} md={4} className="text-right">
                                        <img
                                            style={{
                                                width: "64px",
                                                height: "auto",
                                            }}
                                            src="/static/images/icon5.svg"
                                        />
                                    </Col>
                                    <Col xs={8} md={8}>
                                        <p
                                            className="text-left text-secondary"
                                            style={{ lineHeight: "4.4" }}
                                        >
                                            Nâng cao chất lượng
                                        </p>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs={4} md={4} className="text-right">
                                        <img
                                            style={{
                                                width: "64px",
                                                height: "auto",
                                            }}
                                            src="/static/images/icon6.svg"
                                        />
                                    </Col>
                                    <Col xs={8} md={8}>
                                        <p
                                            className="text-left text-secondary"
                                            style={{ lineHeight: "4.4" }}
                                        >
                                            Tiết kiệm chi phí
                                        </p>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>
                    </div>
                </Container>
            </div>
        );
    }
}
