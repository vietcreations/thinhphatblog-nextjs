import React from "react";
import "../sass/styles.scss";

export default class Footer extends React.Component {
    render() {
        return (
            <div className="copyright">
                <p>
                    © 2018 Thinh Phat JSC.{" "}
                    <a href="javascript:;">Developed by Viet Creations.</a>
                </p>
            </div>
        );
    }
}
