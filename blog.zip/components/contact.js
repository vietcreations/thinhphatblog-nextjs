import React from "react";
import "../sass/styles.scss";

export default class Contact extends React.Component {
    render() {
        return (
            <div
                id="lien-he"
                className="hero background"
                style={{
                    backgroundImage: `url('/static/images/bg-1.png')`,
                    backgroundAttachment: "inherit",
                    backgroundSize: "contain",
                }}
            >
                <div className="container">
                    <div className="spacer" />
                    <div className="spacer" />
                    <div className="spacer" />
                    <div className="spacer" />
                    <img
                        style={{ width: "150px", height: "auto" }}
                        src="/static/images/logo.png"
                    />
                    <div className="spacer" />
                    <p className="h3 text-dark">Thông tin liên hệ</p>
                    <div className="spacer" />
                    <p className="text-dark h5">
                        <a href="javascript:;">
                            <b>CÔNG TY CỔ PHẦN SẢN XUẤT PHÂN BÓN THỊNH PHÁT</b>
                        </a>
                    </p>
                    <div className="spacer" />
                    <p className="text-dark">
                        <b>Địa chỉ:</b> Thôn La Gián, Xã Cổ Đông, Thị Xã Sơn
                        Tây, Thành phố Hà Nội, Việt Nam
                    </p>
                    <div className="text-center">
                        <a
                            className="button button-secondary"
                            href="tel:02433610099"
                        >
                            <span
                                style={{
                                    background: `url('/static/images/icon-phone.png')`,
                                }}
                            />
                            024 336 100 99
                        </a>
                    </div>
                    <div className="spacer" />
                    <div className="spacer" />
                    <p className="h6 text-dark">Là thành viên của</p>
                    <div className="spacer" />
                    <p className="text-dark h4">
                        <a href="javascript:;">
                            <b>TẬP ĐOÀN NTEA VIỆT NAM</b>
                        </a>
                    </p>
                    <div className="spacer" />
                    <img
                        style={{ maxWidth: "100%" }}
                        src="/static/images/logo-nteagroup.png"
                    />
                    <div className="spacer" />
                    <div className="spacer" />
                    <div className="spacer" />
                    <div className="spacer" />
                    <div className="spacer" />
                </div>
            </div>
        );
    }
}
